# SkillBD Android v1
বাংলা-first skill learning Android prototype.

Includes: Home, Courses, Course details, Lessons, Quiz, Progress, Certificate, Profile and bottom navigation.

This is a functional prototype. Video content, login/backend, real certificates, database and publishing can be connected in later versions.

For AndroidForge: upload this ZIP directly; project files are at the ZIP root (no extra wrapper folder).
