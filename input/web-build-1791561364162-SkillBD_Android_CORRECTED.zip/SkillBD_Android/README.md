# SkillBD — Android Starter

এটি SkillBD অ্যাপের প্রথম Android prototype।

## কী আছে
- বাংলা Home screen
- Skill categories
- Search field
- আজকের Skill section
- Category buttons

## Android Studio
1. Android Studio খুলুন।
2. এই project folder Open করুন।
3. Gradle sync শেষ হতে দিন।
4. Emulator বা Android ফোনে Run চাপুন।

পরের ধাপে Video Lessons, Quiz, Progress, Login এবং Certificate যোগ করা যাবে।
