package com.skillbd.app;

import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        int[] ids = {R.id.computerBtn,R.id.videoBtn,R.id.designBtn,R.id.aiBtn,R.id.freelanceBtn,R.id.englishBtn};
        String[] names = {"Computer & MS Office","Video Editing","Graphic Design","AI Tools","Freelancing","English"};

        for (int i=0;i<ids.length;i++) {
            final String name = names[i];
            findViewById(ids[i]).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                    .setTitle(name)
                    .setMessage("এই কোর্সটি SkillBD-এর পরবর্তী ভার্সনে Lesson, Video এবং Quiz সহ যুক্ত হবে।")
                    .setPositiveButton("ঠিক আছে", null)
                    .show()
            );
        }
    }
}
