package com.skillbd.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int green=Color.rgb(22,122,82);
    String[] courses={"💻 Computer & MS Office","🎬 Video Editing","🎨 Graphic Design","📣 Digital Marketing","🤖 AI Tools","💼 Freelancing","🇬🇧 English"};
    public void onCreate(Bundle b){super.onCreate(b); home();}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY); t.setPadding(24,18,24,18); return t;}
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b;}
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        TextView h=tv("SkillBD\n"+title,22); h.setTextColor(Color.WHITE); h.setBackgroundColor(green); h.setTypeface(null,1);
        root.addView(h,new LinearLayout.LayoutParams(-1,90));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,12,18,8);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        String[] n={"🏠 Home","📚 Courses","📈 Progress","👤 Profile"};
        for(String x:n){Button b=btn(x); nav.addView(b,new LinearLayout.LayoutParams(0,60,1));
            if(x.contains("Home")) b.setOnClickListener(v->home());
            if(x.contains("Courses")) b.setOnClickListener(v->courses());
            if(x.contains("Progress")) b.setOnClickListener(v->progress());
            if(x.contains("Profile")) b.setOnClickListener(v->profile());
        }
        root.addView(nav); setContentView(root);
    }
    void home(){
        base("শিখুন • অনুশীলন করুন • এগিয়ে যান");
        content.addView(tv("স্বাগতম 👋",26)); content.addView(tv("বাংলায় সহজভাবে নতুন Skill শেখার জায়গা",18));
        content.addView(tv("🔥 আজকের Skill: Computer Basics",20));
        Button b=btn("আজকের Lesson শুরু করুন"); content.addView(b); b.setOnClickListener(v->lesson("Computer Basics"));
        content.addView(tv("জনপ্রিয় কোর্স",21));
        for(String c:courses){Button x=btn(c); content.addView(x); x.setOnClickListener(v->course(c));}
    }
    void courses(){
        base("সব কোর্স"); for(String c:courses){Button b=btn(c); content.addView(b); b.setOnClickListener(v->course(c));}
    }
    void course(String name){
        base("Course Details"); content.addView(tv(name,25)); content.addView(tv("এই কোর্সে ধাপে ধাপে শেখানো হবে। প্রতিটি Lesson শেষে Quiz থাকবে।",17));
        Button l=btn("▶ Lesson 1 শুরু করুন"); content.addView(l); l.setOnClickListener(v->lesson(name));
    }
    void lesson(String name){
        base("Lesson"); content.addView(tv("🎬 "+name,24)); content.addView(tv("Lesson 1\nভিডিও/লেসন কনটেন্ট এখানে থাকবে।\n\nশিখুন এবং শেষে Quiz দিন।",18));
        Button q=btn("📝 Quiz দিন"); content.addView(q); q.setOnClickListener(v->quiz());
    }
    void quiz(){
        base("Quiz"); content.addView(tv("প্রশ্ন: Computer-এর CPU কী কাজ করে?",20));
        RadioGroup rg=new RadioGroup(this); String[] a={"ডাটা প্রসেস করে","ছবি আঁকে","ইন্টারনেট দেয়","শুধু গান বাজায়"};
        for(String s:a){RadioButton r=new RadioButton(this); r.setText(s); rg.addView(r);} content.addView(rg);
        Button submit=btn("উত্তর জমা দিন"); content.addView(submit); submit.setOnClickListener(v->Toast.makeText(this,"উত্তর সংরক্ষণ হয়েছে ✅",Toast.LENGTH_LONG).show());
    }
    void progress(){base("Progress"); content.addView(tv("📈 আপনার Progress",25)); content.addView(tv("Computer Basics: 40%\nVideo Editing: 20%\nEnglish: 10%",20)); Button c=btn("🎓 Certificate দেখুন"); content.addView(c); c.setOnClickListener(v->certificate());}
    void certificate(){base("Certificate"); content.addView(tv("🎓 SkillBD Certificate",28)); content.addView(tv("অভিনন্দন!\nআপনি একটি কোর্স সম্পন্ন করেছেন।",21));}
    void profile(){base("Profile"); content.addView(tv("👤 Student Profile",26)); content.addView(tv("নাম: Student\nSkillBD Learner",19));}
}