SkillBD phone-ready Android project.
Open as an Android project or upload this ZIP directly to AndroidForge.
Application ID: com.skillbd.app
No external libraries are used.
