# SkillBD Android App v1.1

A Bengali-first Android learning app prototype.

Screens/features: Home, Courses, Lesson, Quiz, Progress, Certificate, Profile and bottom navigation.

Build with AndroidForge:
1. Upload this ZIP as-is (do not extract).
2. Choose Auto or Debug APK.
3. Click Build APK.

The project is intentionally dependency-light. AndroidForge may regenerate the Gradle wrapper JAR on its runner when needed.
