# SkillBD Android
Clean Android source project for AndroidForge.

Features: Home, Courses, Lesson, Quiz, Progress, Certificate, Profile, bottom navigation.

Build with AndroidForge: upload this ZIP directly; do not extract it first. Choose Auto and Build APK.
No external libraries are required.
