package com.skillbd.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN=Color.rgb(11,107,83), DARK=Color.rgb(25,35,31), BG=Color.rgb(246,249,247), WHITE=Color.WHITE, GRAY=Color.rgb(105,115,110);
    LinearLayout root, content, nav; int progress=10;
    final String[] courses={"কম্পিউটার ও MS Office","ভিডিও এডিটিং","গ্রাফিক ডিজাইন","ডিজিটাল মার্কেটিং","AI Tools","Freelancing","English"};
    final String[] icons={"💻","🎬","🎨","📣","🤖","💼","🇬🇧"};

    public void onCreate(Bundle b){super.onCreate(b); showHome();}
    TextView text(String s,int sp,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(c);t.setPadding(20,12,20,12);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    Button action(String s){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setAllCaps(false);b.setTextSize(15);b.setBackgroundColor(GREEN);return b;}
    void shell(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        TextView head=text("SkillBD",23,WHITE,true);head.setBackgroundColor(GREEN);head.setPadding(22,18,22,18);root.addView(head);
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,8,14,18);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setBackgroundColor(WHITE);
        String[] labels={"হোম","কোর্স","প্রগ্রেস","প্রোফাইল"}; for(String x:labels){Button b=new Button(this);b.setText(x);b.setAllCaps(false);b.setTextSize(12);nav.addView(b,new LinearLayout.LayoutParams(0,60,1));if(x.equals("হোম"))b.setOnClickListener(v->showHome());if(x.equals("কোর্স"))b.setOnClickListener(v->showCourses());if(x.equals("প্রগ্রেস"))b.setOnClickListener(v->showProgress());if(x.equals("প্রোফাইল"))b.setOnClickListener(v->showProfile());}
        root.addView(nav);setContentView(root);
        if(title!=null) content.addView(text(title,24,DARK,true),0);
    }
    void showHome(){shell("শিখুন • দক্ষ হন • এগিয়ে যান");content.addView(text("বাংলায় সহজভাবে নতুন স্কিল শিখুন।",16,GRAY,false));
        EditText search=new EditText(this);search.setHint("🔍  কী শিখতে চান?");search.setSingleLine();content.addView(search);
        content.addView(text("জনপ্রিয় কোর্স",20,DARK,true));
        for(int i=0;i<courses.length;i++){final int k=i;Button b=action(icons[i]+"  "+courses[i]);content.addView(b);b.setOnClickListener(v->course(k));}
        content.addView(text("⭐ আজকের Skill\nComputer Basics — ১০ মিনিট\nপ্রতিদিন একটু একটু করে শিখুন।",17,DARK,true));
    }
    void showCourses(){shell("সব কোর্স");for(int i=0;i<courses.length;i++){final int k=i;content.addView(text(icons[i]+"  "+courses[i],19,DARK,true));content.addView(text("৫টি লেসন • প্র্যাকটিস • কুইজ",14,GRAY,false));Button b=action("কোর্স শুরু করুন");content.addView(b);b.setOnClickListener(v->course(k));}}
    void course(int i){shell(courses[i]);content.addView(text("ধাপে ধাপে শেখার জন্য ৫টি ছোট লেসন।",15,GRAY,false));for(int j=1;j<=5;j++){final int l=j;Button b=action("▶ লেসন "+j+"  •  "+(j*8)+" মিনিট");content.addView(b);b.setOnClickListener(v->lesson(i,l));}Button q=action("📝 কুইজ দিন");content.addView(q);q.setOnClickListener(v->quiz());}
    void lesson(int c,int l){shell("ভিডিও লেসন");content.addView(text("লেসন "+l+" — "+courses[c],21,DARK,true));TextView video=text("▶\n\nভিডিও লেসন\nএখানে আপনার কোর্স ভিডিও থাকবে",20,WHITE,true);video.setGravity(Gravity.CENTER);video.setBackgroundColor(Color.rgb(32,42,38));content.addView(video,new LinearLayout.LayoutParams(-1,330));Button done=action("✓ লেসন সম্পন্ন করেছি");content.addView(done);done.setOnClickListener(v->{progress=Math.min(100,progress+10);Toast.makeText(this,"লেসন সম্পন্ন হয়েছে",Toast.LENGTH_SHORT).show();showProgress();});}
    void quiz(){shell("কুইজ");content.addView(text("Computer Basics • ৫ প্রশ্ন",20,DARK,true));String[] qs={"CPU-এর পূর্ণরূপ কী?","MS Word কী কাজে ব্যবহার হয়?","Enter key কী করে?","ফাইল কোথায় রাখা যায়?","ইন্টারনেট কী?"};for(int i=0;i<qs.length;i++){content.addView(text((i+1)+". "+qs[i],16,DARK,true));RadioGroup rg=new RadioGroup(this);for(String o:new String[]{"সঠিক উত্তর","অন্য উত্তর","জানি না"}){RadioButton r=new RadioButton(this);r.setText(o);rg.addView(r);}content.addView(rg);}Button sub=action("কুইজ জমা দিন");content.addView(sub);sub.setOnClickListener(v->{progress=Math.max(progress,25);Toast.makeText(this,"কুইজ সম্পন্ন!",Toast.LENGTH_SHORT).show();showProgress();});}
    void showProgress(){shell("আমার অগ্রগতি");content.addView(text("📈 শেখার অগ্রগতি",22,DARK,true));ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(100);p.setProgress(progress);content.addView(p,new LinearLayout.LayoutParams(-1,55));content.addView(text("অগ্রগতি: "+progress+"%\nসম্পন্ন লেসন: "+Math.max(1,progress/10)+"\nকুইজ: ১",17,GREEN,true));Button c=action("🎓 সার্টিফিকেট দেখুন");content.addView(c);c.setOnClickListener(v->certificate());}
    void certificate(){shell("সার্টিফিকেট");content.addView(text("🏆 SkillBD Certificate",25,GREEN,true));content.addView(text("অভিনন্দন!\n\nআপনি Computer Basics কোর্স শেখার পথে আছেন।\n\nনাম: SkillBD Learner\nস্ট্যাটাস: Learning",18,DARK,false));}
    void showProfile(){shell("আমার প্রোফাইল");content.addView(text("👤 SkillBD Learner",23,DARK,true));content.addView(text("ইমেইল: learner@example.com\nকোর্স: ৭\nব্যাজ: ২",17,GRAY,false));content.addView(action("প্রোফাইল সম্পাদনা"));content.addView(text("\nSkillBD v1.0\nবাংলায় স্কিল শেখার সহজ প্ল্যাটফর্ম।",15,GRAY,false));}
}
